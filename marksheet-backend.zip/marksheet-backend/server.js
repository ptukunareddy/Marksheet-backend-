const express = require("express");
const cors = require("cors");
const app = express();
const port = process.env.PORT || 5000;

app.use(cors());

const marksheetData = {
  "R190821461201": {
    name: "John Doe",
    certificateNo: "21211000000096",
    issueDate: "27-Feb-2023",
    course: "Electrician",
    grade: "A"
  }
};

app.get("/api/marksheet", (req, res) => {
  const roll = req.query.roll;
  const data = marksheetData[roll];

  if (data) {
    res.json(data);
  } else {
    res.status(404).json({ error: "Roll number not found" });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
